package Package2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MainProject {

	public static void main(String[] args) throws SQLException {
		// String query = "Select * from Metadata_Student";
		String table = "Student";
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa",
				"na1903068", "na1903068");
		PreparedStatement pstmt = conn.prepareStatement("Select * from Metadata_Student");
		// Statement stmt = conn.createStatement();
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {

			if (table.equalsIgnoreCase("Depart")) {
				int num_rows = rs.getInt(2);
				int avg_row_size = rs.getInt(3);
				int num_columns = rs.getInt(4);
				String primary_key_columns = rs.getString(5);
				String indexes = rs.getString(7);
				int no_of_block = rs.getInt(10);
				int nums_values_DCode = rs.getInt(11);
				int nums_values_DName = rs.getInt(12);
				int nums_values_DOffice = rs.getInt(13);
				int nums_values_DPhone = rs.getInt(14);
				int nums_values_CName = rs.getInt(15);
				int nums_values_ChairId = rs.getInt(16);
				int nums_values_CStartDate = rs.getInt(17);
			 }
			if (table.equalsIgnoreCase("Student")) {
				int num_rowsS = rs.getInt(2);
				int avg_row_size = rs.getInt(3);
				int num_columns = rs.getInt(4);
				String primary_key_columns = rs.getString(5);
				String indexes = rs.getString(7);
				int no_of_block_Dept = rs.getInt(10);
				int nums_values_StId = rs.getInt(11);
				int nums_values_DOB = rs.getInt(12);
				int nums_values_FName = rs.getInt(13);
				int nums_values_MName = rs.getInt(14);
				int nums_values_LName = rs.getInt(15);
				int nums_values_Addr = rs.getInt(16);
				int nums_values_Phone = rs.getInt(17);
				int nums_values_Major = rs.getInt(18);
				int nums_values_DCode = rs.getInt(19);
				String sortOn = rs.getString(20);
				int blockingFactor = num_rowsS/no_of_block_Dept;

				//estimatePrimaryKeyEqualityCost(no_of_block, num_rowsS);
				estimatePrimaryKeyRangeCost(no_of_block_Dept,num_rowsS,blockingFactor,nums_values_StId);

			}
			if(table == "Join") {
				int num_rows = rs.getInt(2);
				int avg_row_size = rs.getInt(3);
				int num_columns = rs.getInt(4);
				String primary_key_columns = rs.getString(5);
				String indexes = rs.getString(7);
				int no_of_block = rs.getInt(10);
				int nums_values_DCode = rs.getInt(11);
				int nums_values_DName = rs.getInt(12);
				int nums_values_DOffice = rs.getInt(13);
				int nums_values_DPhone = rs.getInt(14);
				int nums_values_CName = rs.getInt(15);
				int nums_values_ChairId = rs.getInt(16);
				int nums_values_CStartDate = rs.getInt(17);
				
				int num_rowsS = rs.getInt(2);
				int avg_row_size_St = rs.getInt(3);
				int num_columns_St = rs.getInt(4);
				String primary_key_columns_St = rs.getString(5);
				String indexes_St = rs.getString(7);
				int no_of_block_St = rs.getInt(10);
				int nums_values_StId = rs.getInt(11);
				int nums_values_DOB = rs.getInt(12);
				int nums_values_FName = rs.getInt(13);
				int nums_values_MName = rs.getInt(14);
				int nums_values_LName = rs.getInt(15);
				int nums_values_Addr = rs.getInt(16);
				int nums_values_Phone = rs.getInt(17);
				int nums_values_Major = rs.getInt(18);
				int nums_values_DCode_St = rs.getInt(19);
				String sortOn = rs.getString(20);
				int blockingFactor = num_rowsS/nums_values_DCode_St;
				
			}
		}
		rs.close();
		conn.close();
	}

	private static void estimatePrimaryKeyEqualityCost(int no_of_block, int num_rows) {
		int squentialSearch = num_rows / 2;
		System.out.println("Sqeuential search always applicable and cost :" + squentialSearch);

		int binarySearch = (int) Math.log(no_of_block);
		System.out.println("binary search will  cost :" + binarySearch);

		int indexPrimary = 2;
		System.out.println("if it index  search will  cost :" + indexPrimary);

		int minimumCost = Math.min(squentialSearch, Math.min(binarySearch, indexPrimary));
		System.out.println("The best plan for searching  this querey : " + minimumCost);

	}

	private static void estimatePrimaryKeyRangeCost(int no_of_block,int num_rows,int blockingFactor,int distinctValueCount) {
	
    	int sequentialSearchCost = no_of_block;
        System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);

	    double selectivity = (double) distinctValueCount / num_rows;
	    
	    double selectivityCard = (double) selectivity *num_rows;

        
        int binarySearchCost = (int)(Math.log(no_of_block)/2) + (int)(selectivityCard/blockingFactor) - 1;
        System.out.println("Binary search will cost: " + binarySearchCost);

        int indexPrimaryCost = 2 + (no_of_block/ 2);
        System.out.println("If it is index search, it will cost: " + indexPrimaryCost);

        int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
        System.out.println("The best plan for searching this query: " + minimumCost);
    }

	private static void estimateNonPrimaryKeyEqualityCostClustring(int no_of_block,int num_rows,int blockingFactor,int distinctValueCount) {
		
    	int sequentialSearchCost = no_of_block/2;
        System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);

        
        int binarySearchCost = (int)(Math.log(no_of_block));
        System.out.println("Binary search will cost: " + binarySearchCost);
        
        
	    double selectivity = (double) distinctValueCount / num_rows;
	    
        int indexPrimaryCost = (int) (2 + (selectivity/ blockingFactor));
        System.out.println("If it is index search, it will cost: " + indexPrimaryCost);
	
		System.out.println("Clustering  search by index will cost: "+indexPrimaryCost);

        int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
        System.out.println("The best plan for searching this query: " + minimumCost);
	}

	private static void estimateNonPrimaryKeyRangeCostClustring(int no_of_block, int num_rows,int distinctValueCount) {

		int selectivity =  (int) (distinctValueCount / num_rows);
		int blockingFactor = num_rows / no_of_block;

		int sequentialSearchCost = no_of_block;
		System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);

		int binarySearchCost = (int) (Math.log(no_of_block) / 2) +(selectivity / blockingFactor) - 1;
		System.out.println("Binary search will cost: " + binarySearchCost);

		int indexPrimaryCost = 2 + (int) (selectivity * num_rows / blockingFactor);
		System.out.println("If it is index search, it will cost: " + indexPrimaryCost);

		System.out.println("Clustering search by index will cost: " + indexPrimaryCost);

		int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
		System.out.println("The best plan for searching this query: " + minimumCost);
	}

	private static void estimateNonPrimaryKeyEqualityCostSecondary(int no_of_block, int num_rows,int blockingFactor,int distinctValueCount) {

		
		int sequentialSearchCost = no_of_block;
	    System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);

	    double selectivity = (double) distinctValueCount / num_rows;

	    int binarySearchCost = (int)(Math.log(no_of_block) / Math.log(2)) + (int)(selectivity * num_rows / blockingFactor) - 1;
	    System.out.println("Binary search will cost: " + binarySearchCost);

	    int selectionCardinality = (int) (selectivity * num_rows);
	    int indexTraversalCost = 2;
	    int matchingBlocks = (int) Math.ceil((double) selectionCardinality / blockingFactor);

	    int indexPrimaryCost = indexTraversalCost + matchingBlocks;
	    System.out.println("Clustering search by index will cost: " + indexPrimaryCost);

	    int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
	    System.out.println("The best plan for searching this query: " + minimumCost);
	}

private static void estimateNonPrimaryKeyRangeCostSecondary(int no_of_block, int num_rows,int distinctValueCount,int blockingFactor) {

		int sequentialSearchCost = no_of_block;
		System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);
		
	    double selectivity = (double) distinctValueCount / num_rows;


		int binarySearchCost = (int) (Math.log(no_of_block) /2) + (int) (selectivity / blockingFactor) - 1;
		System.out.println("Binary search will cost: " + binarySearchCost);

		int selectionCardinality = (int) (selectivity * num_rows); // Estimated number of rows returned by the
																				// query
		int indexTraversalCost = 2; // Cost to traverse the index to the first matching record
		int matchingBlocks = (int) Math.ceil((double) selectionCardinality / blockingFactor); // Blocks containing
																								// matching records
		 int indexPrimaryCost =indexTraversalCost + matchingBlocks;
		System.out.println("Clustering  search by index will cost: " + indexPrimaryCost);

		int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
		System.out.println("The best plan for searching this query: " + minimumCost);
	}

	
public static void estimateJoinCosts(String sortOn,int no_of_block_Dept,int num_rows,int num_rowsS,String indexes,String joinColumn,int blockingFactor,
		int no_of_block_Std){

	    double joinSelectivity = calculateJoinSelectivity(num_rows, num_rowsS);
	    double joinCardinality = calculateJoinCardinality(joinSelectivity, num_rows, num_rowsS);

	    // If data is sorted on the join key, prefer sort-merge join.
	    if (sortOn != null && sortOn.equals(joinColumn)) {
	         estimateSortMergeJoinCost(blockingFactor,  joinCardinality, no_of_block_Std, no_of_block_Dept);
	    }
	    // If an index is available on the join column, use index-nested loop join.
	    else if (indexes != null && indexes.contains(joinColumn)) {
	         estimateIndexNestedLoopJoinCost(no_of_block_Dept, joinCardinality, num_rows, num_rowsS, num_rows);
	    }
	    // Default to nested loop join if no index is available.
	    else {
	         estimateNestedLoopJoinCost(no_of_block_Dept, joinCardinality, num_rows, num_rowsS);
	    }
	}
		


	private static double calculateJoinSelectivity(int num_rows, int num_rowsS) {
		return 1.0 / Math.max(num_rows, num_rowsS);
}

	private static double calculateJoinCardinality(double joinSelectivity, int numRecordsR, int numRecordsS) {
	return joinSelectivity * numRecordsR * numRecordsS;
}
	


	private static void estimateSortMergeJoinCost(int blockingFactor, double joinCardinality,int no_of_block_Std,int no_of_block_Dept) {
     // Assuming relations are already sorted on the join key
		Double SortMerge= no_of_block_Dept + no_of_block_Std + (joinCardinality / blockingFactor);
		System.out.println("SortMerge search  applicable and cost: " + SortMerge);
	}

	private static void estimateNestedLoopJoinCost(int blockingFactor, double joinCardinality,int no_of_block_Std,int no_of_block_Dept) {
		Double NestedLoop =  no_of_block_Dept + (no_of_block_Dept *no_of_block_Std) + (joinCardinality / blockingFactor);
		System.out.println("Nested Loop search  applicable and cost: " + NestedLoop);

	}

	private static void estimateIndexNestedLoopJoinCost(int blockingFactor, double joinCardinality,int no_of_block_Std,int no_of_block_Dept,int num_rows) {
		Double indexNestedLoop = (num_rows * (4 + 1) + (joinCardinality / blockingFactor));
		System.out.println("Nested Loop search  applicable and cost: " + indexNestedLoop);

		
	}

}
