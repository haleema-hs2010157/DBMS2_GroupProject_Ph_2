Metadata_Departimport java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class costExsitmation {
	

	private static void initializeColumns(Map<Integer, String> studCols, Map<Integer, String> departCols) {
		// Fill studCols and departCols with respective column data

	
		studCols.put(1, "Stid");
		studCols.put(2, "DOB");
		studCols.put(3, "FName");
		studCols.put(4, "MName");
		studCols.put(5, "LName");
		studCols.put(6, "Addr");
		studCols.put(7, "Phone");
		studCols.put(8, "Major");
		studCols.put(9, "DCode");

		departCols.put(1, "DCode");
		departCols.put(2, "DName");
		departCols.put(3, "DOffice");
		departCols.put(4, "DPhone");
		departCols.put(5, "CName");
		departCols.put(6, "ChairId");
		departCols.put(7, "CStartDate");
	}
	
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws SQLException {
		

		Map<Integer, String> studCols = new HashMap<>();
		Map<Integer, String> departCols = new HashMap<>();
		List<String> cols = new ArrayList<>();
		String command = "";
		String table = "";

		initializeColumns(studCols, departCols);

		while (true) {
			System.out.println("Please choose one of the following options:\na - Select \nb - Join");
			String comChoice = scanner.nextLine().toLowerCase();
			if (comChoice.equals("a")) {
				command = "select";
				break;
			} else if (comChoice.equals("b")) {
				command = "join";
				break;
			} else {
				System.out.println("Invalid choice. Please enter a valid option: a or b.");
			}
		}
		
		if(command == "select") {
		while(true) {
			System.out.println("Please choose the table you want to select from:\na - Student \nb - Department");
			String tabChoice = scanner.nextLine().toLowerCase();

			if (tabChoice.equals("a")) {
				table = "Student";
				break;
			} else if (tabChoice.equals("b")) {
				table = "Depart";
				break;
			} else {
				System.out.println("Invalid choice. Please enter a valid option: a or b.");
			}
		}
			if (table.equals("Depart")) {
				System.out.println(
						"These are the columns in the Department table:\\n1. DCode \\n2. DName\\n3. DOffice\\n4. DPhone\\n5. CName (College Name)\\n6. ChairId\\n7. CStartDate");

				while (true) {
					System.out.println("Please enter the numbers of the columns you want separated by a single space:");
					String[] colsChoice = scanner.nextLine().trim().split("\\s+");

					for (String choice : colsChoice) {
						try {
							int colNum = Integer.parseInt(choice);

							if (departCols.containsKey(colNum)) {
								cols.add(departCols.get(colNum));
							} else {
								System.out.println(
										"Invalid column number: " + colNum + ". Please enter a valid column number.");
							}
						} catch (NumberFormatException e) {
							System.out.println("Invalid input. Please enter valid numbers.");
						}
					}

					if (!cols.isEmpty()) {
						break;
					}
				}
			}

			if (table.equals("Student")) {
				System.out.println(
						"These are the coloumns in the Student table:\\n1. Sid (Student ID) \\n2. DOB (Date of Birth)\r\n"
								+ "\\n3.FName (First Name)\\n4. MName (Middle Name)\\n5. LName (Last Name)\\n6. Addr (Address)\\n7. Phone (Phone number)\\n8. Major\\n9. DCode (Department Number)");

				while (true) {
					System.out.println("Please enter the numbers of the columns you want separated by a single space:");
					String[] colsChoice = scanner.nextLine().trim().split("\\s+");

					for (String choice : colsChoice) {
						try {
							int colNum = Integer.parseInt(choice);

							if (studCols.containsKey(colNum)) {
								cols.add(studCols.get(colNum));
							} else {
								System.out.println(
										"Invalid column number: " + colNum + ". Please enter a valid column number.");
							}
						} catch (NumberFormatException e) {
							System.out.println("Invalid input. Please enter valid numbers.");
						}
					}

					if (!cols.isEmpty()) {
						break;
					}
				}
			}
		}
		else if (command.equals("join")) {
				System.out.println(
						"There's only one column in common to join, and we automatically select the smaller one as outer so.");
}

		
		String query = buildQuery(cols, table);
		
		

		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa","na1903068", "na1903068");
		PreparedStatement pstmt = conn.prepareStatement(query);
		//Statement stmt = conn.createStatement();
		ResultSet rs = pstmt.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		System.out.println(metaData);
		
	}
	
	 private static String buildQuery(List<String> cols, String table) {
	        List<String> formattedCols = new ArrayList<>();
	        for (String col : cols) {
	            if (col.contains(" ")) {
	                // Assuming column names like "Sid (Student ID)" are actually "Sid"
	                String actualCol = col.split(" ")[0]; // Extracts "Sid" from "Sid (Student ID)"
	                formattedCols.add("\"" + actualCol + "\"");
	            } else {
	                formattedCols.add(col);
	            }
	        }
	        String columns = String.join(", ", formattedCols);
	        return "SELECT " + columns + " FROM " + table;
	    }
	
}
		