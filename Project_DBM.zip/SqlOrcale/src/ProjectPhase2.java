

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class CostCalc {

    public static void main(String[] args) {
        System.out.println("Welcome to DBMS 451 Query Cost Calculator");
        String command = "";
        String table = "";
        Boolean primaryChosen = true;
        int workingCol = 0;
        int queryType = -1;
        ArrayList<String> cols = new ArrayList<>();
        HashMap<Integer, String> studCols = new HashMap<>();
        studCols.put(1, "Sid (Student ID)");
        studCols.put(2, "DOB (Date of Birth)");
        studCols.put(3, "FName (First Name)");
        studCols.put(4, "MName (Middle Name)");
        studCols.put(5, "LName (Last Name)");
        studCols.put(6, "Addr (Address)");
        studCols.put(7, "Phone (Phone number)");
        studCols.put(8, "Major");
        studCols.put(9, "DCode (Department Number)");

        HashMap<Integer, String> departCols = new HashMap<>();
        departCols.put(1, "DCode");
        departCols.put(2, "DName");
        departCols.put(3, "DOffice");
        departCols.put(4, "DPhone");
        departCols.put(5, "CName");
        departCols.put(6, "ChairId");
        departCols.put(7, "CStartDate");

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Please choose one of the following options:\na - Select \nb - Join");
            String comChoice = scanner.nextLine().toLowerCase();
            if (comChoice.equals("a")) {
                command = "select";
                break;
            } else if (comChoice.equals("b")) {
                command = "join";
                break;
            } else {
                System.out.println("Invalid choice. Please enter a valid option: a or b .");
            }
        }

        if (command.equals("select")) {
            while (true) {
                System.out.print("Please choose the table you want to select from:\na - Student \nb - Department");
                String tabChoice = scanner.nextLine().toLowerCase();
                if (tabChoice.equals("a")) {
                    table = "Student";
                    break;
                } else if (tabChoice.equals("b")) {
                    table = "Depart";
                    break;
                } else {
                    System.out.println("Invalid choice. Please enter a valid option: a or b .");
                }
            }

            if (table.equals("Depart")) {
                System.out.println("These are the columns in the Department table:\n1. DCode 2.DName\n3. DOffice\n4. DPhone\n5. CName (College Name)\n6. ChairId\n7. CStartDate");
                System.out.print("Please enter the number of the columns that you want PRINTED separated by a single space: ");
                String colsChoice = scanner.nextLine();
                for (String choice : colsChoice.split(" ")) {
                    try {
                        int colNum = Integer.parseInt(choice);
                        if (departCols.containsKey(colNum)) {
                            cols.add(departCols.get(colNum));
                        } else {
                            System.out.println("Invalid column number: " + colNum + ". Please enter a valid column number.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                    }
                }
                
                
            }

            if (table.equals("Student")) {
                System.out.println("These are the columns in the Student table:\n1. Sid (Student ID) \n2. DOB (Date of Birth)\n3. FName (First Name)\n4. MName (Middle Name)\n5. LName (Last Name)\n6. Addr (Address)\n7. Phone (Phone number)\n8. Major\n9. DCode (Department Number)");
                System.out.print("Please enter the number of the columns that you want PRINTED separated by a single space: ");
                String colsChoice = scanner.nextLine();
                for (String choice : colsChoice.split(" ")) {
                    try {
                        int colNum = Integer.parseInt(choice);
                        if (studCols.containsKey(colNum)) {
                            cols.add(studCols.get(colNum));
                        } else {
                            System.out.println("Invalid column number: " + colNum + ". Please enter a valid column number.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                    }
                }
            }
            
            System.out.print("Do you want to work on the primary key? (yes/no): ");
            String primaryKeyChoice = scanner.nextLine().toLowerCase();
            
            if (primaryKeyChoice.equals("yes")) {
            		workingCol = 1;
            } else if (primaryKeyChoice.equals("no")) {
                if(table=="Student") {
                	System.out.println("These are the columns in the Student table:\n1. Sid (Student ID) \n2. DOB (Date of Birth)\n3. FName (First Name)\n4. MName (Middle Name)\n5. LName (Last Name)\n6. Addr (Address)\n7. Phone (Phone number)\n8. Major\n9. DCode (Department Number)");
                    System.out.print("Please enter the number of the column that you want in the WHERE clause: ");
                    workingCol = scanner.nextInt();
                    //System.out.print("Ehe: "+selectedCol);
                    
                } else {
                	System.out.println("These are the columns in the Department table:\n1. DCode 2.DName\n3. DOffice\n4. DPhone\n5. CName (College Name)\n6. ChairId\n7. CStartDate");
                    System.out.print("Please enter the number of the column that you want in the WHERE clause: ");
                    workingCol = scanner.nextInt();
                }
            } else {
                System.out.println("Invalid choice. Please enter 'yes' or 'no'.");
            }
            
            System.out.println("Will you be working with equality (0) or range (1)");
            int qType = scanner.nextInt();
            if(qType == 0 || qType == 1) {
            	queryType = qType;
            }
            
            

            
            
            
            
            
            
        } else if (command.equals("join")) {
            System.out.println("There's only one column in common to join, and we automatically select the smaller one as outer.");
        }

        // Del after test
        // System.out.println("You have selected the following columns:");
        // for (String colName : cols) {
        //     System.out.println(colName);
        // }

        // Double-check column names are spelled the same as code
        // Student(Sid number(9) primary key, DOB date, FName varchar2(20), MName
        // varchar2(20), LName varchar2(20), Addr varchar2(30), Phone number(8), Major
        // varchar2(10), DCode number(9))
    }
}