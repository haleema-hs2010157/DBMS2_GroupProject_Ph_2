import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class costCaculator {

	public static void main(String[] args) throws SQLException {
		
		
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa","na1903068", "na1903068");
		PreparedStatement pstmt = conn.prepareStatement("Select * from Student");
		//Statement stmt = conn.createStatement();
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			int StId = rs.getInt(1);
			System.out.println(StId + "");

		}
		rs.close();
		conn.close();

	}

}
