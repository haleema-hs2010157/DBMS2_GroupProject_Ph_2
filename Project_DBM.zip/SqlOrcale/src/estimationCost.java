import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import oracle.ucp.routing.Chunk.Metadata;

public class estimationCost {

	
	public static void main(String[] args) throws SQLException {
		
//		private static void estimateNonPrimaryKeyEqualityCostClustring(ResultSetMetaData metaData) {
//			
//	    	//int sequentialSearchCost = metaData.numberOfBlocks;
////	        System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);
////
////	        int binarySearchCost = (int)(Math.log(metaData.numberOfBlocks) / Math.log(2))+ (int)(selectivity / metaData.blockingFactor) - 1;
////	        System.out.println("Binary search will cost: " + binarySearchCost);
//	    	
////			int selectionCardinality = (int) (selectivity * metaData.tableSize); // Estimated number of rows returned by the query
////	        int indexTraversalCost = indexTreeHeight; // Cost to traverse the index to the first matching record
////	        int matchingBlocks = (int) Math.ceil((double) selectionCardinality / blockingFactor); // Blocks containing matching records    	
//	    	//indexPrimaryCost =indexTraversalCost + matchingBlocks 
////			System.out.println("Clustering  search by index will cost: "+indexPrimaryCost);
//////
////	        int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
////	        System.out.println("The best plan for searching this query: " + minimumCost);
//		}		
//
//	    private static double estimateNonPrimaryKeyEqualityCost(ResultSetMetaData metaData) {
////	    	int sequentialSearchCost = metaData.numberOfBlocks/2;
////	        System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);
////
////	        int binarySearchCost = (int)(Math.log(metaData.numberOfBlocks) / Math.log(2));
////	        System.out.println("Binary search will cost: " + binarySearchCost);
////
//	    	// indexTreeHeight is 'x'
//	        // selectionCardinality is 's'
//	       // indexPrimaryCost= indexTreeHeight + 1 + selectionCardinality;
////			System.out.println("Secondary search by index will cost: "+indexPrimaryCost);
////	        int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
////	        System.out.println("The best plan for searching this query: " + minimumCost);
//	        return 3.0;
//	    }
//
//	    private static double estimateNonPrimaryKeyRangeCost(ResultSetMetaData metaData) {
//			
//	    	//int sequentialSearchCost = metaData.numberOfBlocks;
////	        System.out.println("Sequential search always applicable and cost: " + sequentialSearchCost);
////
////	        int binarySearchCost = (int)(Math.log(metaData.numberOfBlocks) / Math.log(2))+ (int)(selectivity / metaData.blockingFactor) - 1;
////	        System.out.println("Binary search will cost: " + binarySearchCost);
//	    	
//	    	//double indexTraversalCost = indexTreeHeight; // Cost to traverse the index to the range's starting point
//	        //double firstLevelIndexBlocksCost = firstLevelIndexBlocks / 2.0; // On average, half the first-level index blocks are accessed
//	        //double recordRetrievalCost = totalRecords / 2.0; // On average, half the records might be accessed
//	         
//	    	//indexPrimaryCost =indexTraversalCost + firstLevelIndexBlocksCost + recordRetrievalCost;
////			System.out.println("Clustering  search by index will cost: "+indexPrimaryCost);
//
////	        int minimumCost = Math.min(sequentialSearchCost, Math.min(binarySearchCost, indexPrimaryCost));
////	        System.out.println("The best plan for searching this query: " + minimumCost);
//	        return 4.0;
//	    }
//

	}
}
